from kivy.app import App
from kivy.uix.screenmanager import ScreenManager

class Control(ScreenManager):
    pass



class BitetrisApp(App):
    pass

if __name__ == '__main__':
    BitetrisApp().run()